# GreenSchedule — Static SPA Conversion

## Conversion Summary

This project has been successfully converted from **TanStack Start (SSR)** to **standard React + Vite (SPA)**.

### What Changed

#### Removed (SSR-only)
- `@tanstack/react-start` — full-stack framework
- `@tanstack/router-plugin` — TanStack Start's router plugin
- `@lovable.dev/vite-tanstack-config` — SSR build config
- `nitro` — server framework
- `src/server.ts` — server entry point
- SSR-specific code in `__root.tsx` (HeadContent, Scripts, shellComponent)

#### Added/Updated
- `vite.config.ts` — standard Vite config with React plugin
- `index.html` — SPA entry point
- `src/start.ts` — client-only React + Router setup
- `_redirects` — Netlify SPA routing config
- `package.json` — updated deps, removed SSR packages

#### Preserved (No Changes)
- ✓ All UI components (Radix, Tailwind, shadcn)
- ✓ All routes (`/`, `/board`)
- ✓ All business logic (JobStore, JobOrchestrator, RecurrenceEngine)
- ✓ All localStorage functionality
- ✓ Calendar export (ICS)
- ✓ Weather simulation
- ✓ TanStack Router (client-side only)
- ✓ React Query
- ✓ Error boundaries and error handling

### Architecture

**Before:**
```
TanStack Start (SSR)
├── server.ts (Node.js backend)
├── vite.config.ts (SSR build)
└── Routes rendered on server + hydrated on client
```

**After:**
```
React + Vite (SPA)
├── index.html (static entry)
├── vite.config.ts (simple Vite config)
└── Routes rendered entirely on client
```

### Features Status

| Feature | Status | Notes |
|---------|--------|-------|
| Job CRUD | ✓ Works | 100% localStorage-based |
| Recurring jobs | ✓ Works | RecurrenceEngine untouched |
| Calendar export | ✓ Works | ICS download to device |
| Weather simulation | ✓ Works | Job orchestration logic preserved |
| Apple Maps | ✓ Works | Deep links untouched |
| Mobile Web App | ✓ Works | manifest.webmanifest intact |
| Navigation | ✓ Works | TanStack Router SPA mode |
| Error handling | ✓ Works | Client-side error boundaries |

### Deployment

Deploy to Netlify using:
1. Extract the zip
2. Drag folder to Netlify (or push to GitHub)
3. Netlify automatically finds `_redirects` and `index.html`
4. SPA routing works for all paths (`/`, `/board`)

### Build & Dev

```bash
# Install dependencies
pnpm install

# Dev server
pnpm dev

# Build static site
pnpm build

# Output: dist/ folder (ready for Netlify)
```

### No Server Dependencies

This app is **100% client-side**. All data is stored in:
- `localStorage` (persistent jobs)
- React state (temporary UI state)
- In-memory singletons (kernel stores)

No API calls, no backend, no database.
