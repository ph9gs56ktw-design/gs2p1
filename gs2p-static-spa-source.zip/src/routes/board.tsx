import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { useKernel } from '@/hooks/useKernel';
import { exportJobToICSDefaultWindow, type Job, type Recurrence } from '@/lib/kernel';

export const Route = createFileRoute('/board')({
  head: () => ({
    meta: [{ title: 'Board — GreenSchedule' }],
  }),
  component: BoardPage,
});

const STATUS_LABEL: Record<Job['status'], string> = {
  scheduled: 'Scheduled',
  in_progress: 'In progress',
  delayed: 'Delayed',
  rescheduled: 'Rescheduled',
  manual_override: 'Manual override',
  completed: 'Completed',
};

function makeId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'job-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

function downloadICS(job: Job) {
  if (typeof window === 'undefined') return;
  const ics = exportJobToICSDefaultWindow(job);
  const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${job.title.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.ics`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function BoardPage() {
  // Gate interactive content until after mount so server HTML (no jobs) matches
  // the first client render, then swap to real localStorage-backed state.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const { jobs, days, store, orchestrator } = useKernel();

  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [address, setAddress] = useState('');
  const [hours, setHours] = useState('1');
  const [recurrence, setRecurrence] = useState<Recurrence>('none');

  function addJob() {
    if (!title.trim() || !date.trim() || !address.trim()) return;
    store.addJob({
      id: makeId(),
      title: title.trim(),
      scheduledDate: date,
      location: { address: address.trim(), timeZone: 'Europe/London' },
      estimatedHours: Number(hours) || 1,
      recurrence,
    });
    setTitle('');
    setDate('');
    setAddress('');
    setHours('1');
    setRecurrence('none');
  }

  function moveJob(id: string) {
    const next = window.prompt('Move to date (YYYY-MM-DD)');
    if (!next) return;
    orchestrator.move(id, next);
  }

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background px-4 py-8 text-foreground">
        <div className="mx-auto max-w-3xl text-sm text-muted-foreground">Loading board…</div>
      </div>
    );
  }

  const inputClass =
    'w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring';

  return (
    <div className="min-h-screen bg-background px-4 py-8 text-foreground">
      <div className="mx-auto max-w-3xl">
        <header className="mb-6">
          <h1 className="text-2xl font-semibold tracking-tight">Board</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Jobs, daily load and weather — running on the new engine. Your main page is untouched.
          </p>
        </header>

        {/* Add job */}
        <section className="mb-8 rounded-xl border border-border bg-card p-4">
          <h2 className="mb-3 text-sm font-medium">Add a job</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <input className={inputClass} placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
            <input className={inputClass} type="date" value={date} onChange={e => setDate(e.target.value)} />
            <input className={inputClass} placeholder="Address" value={address} onChange={e => setAddress(e.target.value)} />
            <input className={inputClass} type="number" min="0" step="0.5" placeholder="Hours" value={hours} onChange={e => setHours(e.target.value)} />
            <select className={inputClass} value={recurrence} onChange={e => setRecurrence(e.target.value as Recurrence)}>
              <option value="none">No repeat</option>
              <option value="weekly">Weekly</option>
              <option value="fortnightly">Fortnightly</option>
              <option value="monthly">Monthly</option>
            </select>
          </div>
          <button
            onClick={addJob}
            className="mt-3 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Add job
          </button>
        </section>

        {/* Day summary */}
        <section className="mb-8">
          <h2 className="mb-3 text-sm font-medium">Days</h2>
          {days.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border p-4 text-sm text-muted-foreground">
              No upcoming days yet. Add a job to see daily totals.
            </p>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {days.map(day => (
                <div key={day.date} className="rounded-lg border border-border bg-card p-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{day.date}</span>
                    <span className={day.isOverloaded ? 'text-sm font-medium text-destructive' : 'text-sm text-muted-foreground'}>
                      {day.totalHours}h{day.isOverloaded ? ' · over 8h' : ''}
                    </span>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">{day.jobIds.length} job(s)</div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Weather test */}
        <section className="mb-8 rounded-xl border border-border bg-card p-4">
          <h2 className="mb-1 text-sm font-medium">Test weather</h2>
          <p className="mb-3 text-xs text-muted-foreground">
            Marks every pending job on a day as delayed (simulates a HIGH-risk forecast).
          </p>
          <div className="flex flex-wrap gap-2">
            {days.map(day => (
              <button
                key={day.date}
                onClick={() =>
                  orchestrator.applyWeather(day.date, {
                    precipitationProbability: 90,
                    riskLevel: 'HIGH',
                    suggestion: 'Delay outdoor work',
                  })
                }
                className="rounded-md border border-input bg-background px-3 py-1.5 text-xs font-medium transition-colors hover:bg-accent"
              >
                Delay {day.date}
              </button>
            ))}
            {days.length === 0 && <span className="text-xs text-muted-foreground">Add a job first.</span>}
          </div>
        </section>

        {/* Jobs */}
        <section>
          <h2 className="mb-3 text-sm font-medium">All jobs</h2>
          {jobs.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border p-4 text-sm text-muted-foreground">
              No jobs yet.
            </p>
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {jobs
                .slice()
                .sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate))
                .map(job => (
                  <div key={job.id} className="rounded-lg border border-border bg-card p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-medium">{job.title}</div>
                        <div className="text-sm text-muted-foreground">{job.scheduledDate} · {job.estimatedHours}h</div>
                        <div className="text-sm text-muted-foreground">{job.location.address}</div>
                        {job.recurrence !== 'none' && (
                          <div className="mt-1 text-xs text-muted-foreground">Repeats: {job.recurrence}</div>
                        )}
                      </div>
                      <span className="shrink-0 rounded-full border border-border px-2 py-0.5 text-xs">
                        {STATUS_LABEL[job.status]}
                      </span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <ActionButton onClick={() => orchestrator.setStatus(job.id, 'in_progress', { trigger: 'user_action' })}>Start</ActionButton>
                      <ActionButton onClick={() => orchestrator.setStatus(job.id, 'completed', { trigger: 'user_action' })}>Complete</ActionButton>
                      <ActionButton onClick={() => orchestrator.setStatus(job.id, 'delayed', { trigger: 'user_action' })}>Delay</ActionButton>
                      <ActionButton onClick={() => orchestrator.setStatus(job.id, 'rescheduled', { trigger: 'user_action' })}>Reschedule</ActionButton>
                      <ActionButton onClick={() => moveJob(job.id)}>Move date</ActionButton>
                      <ActionButton onClick={() => downloadICS(job)}>Add to calendar</ActionButton>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function ActionButton({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="rounded-md border border-input bg-background px-3 py-1.5 text-xs font-medium transition-colors hover:bg-accent"
    >
      {children}
    </button>
  );
}
