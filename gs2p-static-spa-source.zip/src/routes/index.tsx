import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GreenSchedule — Garden & Landscaping Jobs" },
      {
        name: "description",
        content:
          "On-site notes, recurring calendar bookings and Apple Maps directions for garden & landscaping pros.",
      },
      { property: "og:title", content: "GreenSchedule" },
      {
        property: "og:description",
        content:
          "Log on-site visits, book recurring jobs to your calendar and open client addresses in Apple Maps.",
      },
    ],
  }),
  component: Index,
});

type Recurrence = "none" | "weekly" | "fortnightly" | "monthly" | "custom";

type Job = {
  id: string;
  client: string;
  address: string;
  summary: string;
  date: string; // yyyy-mm-dd
  time: string; // HH:mm
  durationMin: number;
  recurrence: Recurrence;
  customIntervalWeeks?: number;
  createdAt: number;
};

const STORAGE_KEY = "greenschedule.jobs.v1";

function loadJobs(): Job[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Job[]) : [];
  } catch {
    return [];
  }
}

function saveJobs(jobs: Job[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(jobs));
}

function pad(n: number) {
  return n.toString().padStart(2, "0");
}

// UTC stamp (used for DTSTAMP only — required to be UTC per RFC 5545)
function toICSDateUTC(d: Date) {
  return (
    d.getUTCFullYear().toString() +
    pad(d.getUTCMonth() + 1) +
    pad(d.getUTCDate()) +
    "T" +
    pad(d.getUTCHours()) +
    pad(d.getUTCMinutes()) +
    "00Z"
  );
}

// Floating local time — Apple Calendar shows it at the wall-clock time the user entered,
// regardless of the device's current timezone. Cleaner than forcing UTC.
function toICSDateLocal(dateStr: string, time: string, addMinutes = 0) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = time.split(":").map(Number);
  const base = new Date(y, m - 1, d, hh, mm).getTime() + addMinutes * 60_000;
  const dt = new Date(base);
  return (
    dt.getFullYear().toString() +
    pad(dt.getMonth() + 1) +
    pad(dt.getDate()) +
    "T" +
    pad(dt.getHours()) +
    pad(dt.getMinutes()) +
    "00"
  );
}

function escapeICS(text: string) {
  return text
    .replace(/\\/g, "\\\\")
    .replace(/\n/g, "\\n")
    .replace(/,/g, "\\,")
    .replace(/;/g, "\\;");
}

function rruleFor(job: Job): string | null {
  switch (job.recurrence) {
    case "weekly":
      return "RRULE:FREQ=WEEKLY;INTERVAL=1";
    case "fortnightly":
      return "RRULE:FREQ=WEEKLY;INTERVAL=2";
    case "monthly":
      return "RRULE:FREQ=MONTHLY;INTERVAL=1";
    case "custom":
      return `RRULE:FREQ=WEEKLY;INTERVAL=${Math.max(1, job.customIntervalWeeks ?? 3)}`;
    default:
      return null;
  }
}

function buildICS(job: Job): string {
  const uid = `${job.id}@greenschedule`;
  const rrule = rruleFor(job);
  const dtStart = toICSDateLocal(job.date, job.time);
  const dtEnd = toICSDateLocal(job.date, job.time, job.durationMin);
  const mapsLink = mapsUrl(job.address);
  const description = (job.summary ? job.summary + "\n\n" : "") + `Directions: ${mapsLink}`;
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//GreenSchedule//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:${toICSDateUTC(new Date())}`,
    `DTSTART:${dtStart}`,
    `DTEND:${dtEnd}`,
    `SUMMARY:${escapeICS(job.client + " — Garden visit")}`,
    `LOCATION:${escapeICS(job.address)}`,
    `DESCRIPTION:${escapeICS(description)}`,
    `URL:${mapsLink}`,
  ];
  if (rrule) lines.push(rrule);
  // 30-min reminder so you get a heads-up before the visit
  lines.push(
    "BEGIN:VALARM",
    "ACTION:DISPLAY",
    `DESCRIPTION:${escapeICS(job.client + " — Garden visit")}`,
    "TRIGGER:-PT30M",
    "END:VALARM",
  );
  lines.push("END:VEVENT", "END:VCALENDAR");
  return lines.join("\r\n");
}

function downloadICS(job: Job) {
  const ics = buildICS(job);
  const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${job.client.replace(/\s+/g, "_") || "job"}.ics`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function mapsUrl(address: string) {
  // maps.apple.com opens Apple Maps on iOS/macOS, falls back to Google Maps elsewhere
  return `https://maps.apple.com/?q=${encodeURIComponent(address)}`;
}

// Driving directions from current location to the address
function directionsUrl(address: string) {
  return `https://maps.apple.com/?daddr=${encodeURIComponent(address)}&dirflg=d`;
}

async function shareJob(job: Job) {
  const text = `${job.client}\n${job.address}\n${job.date} ${job.time}\n\n${job.summary}`;
  const nav = navigator as Navigator & { share?: (data: ShareData) => Promise<void> };
  if (nav.share) {
    try {
      await nav.share({ title: `${job.client} — Garden visit`, text });
      return;
    } catch {
      /* user cancelled */
    }
  }
  try {
    await navigator.clipboard.writeText(text);
    alert("Summary copied — paste into Apple Notes.");
  } catch {
    alert(text);
  }
}

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function formatNice(dateStr: string, time: string) {
  const d = new Date(`${dateStr}T${time}:00`);
  return d.toLocaleString(undefined, {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  });
}

const recurrenceLabel: Record<Recurrence, string> = {
  none: "One-off",
  weekly: "Weekly",
  fortnightly: "Fortnightly",
  monthly: "Monthly",
  custom: "Every N weeks",
};

function Index() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [showForm, setShowForm] = useState(false);

  const [client, setClient] = useState("");
  const [address, setAddress] = useState("");
  const [summary, setSummary] = useState("");
  const [date, setDate] = useState(todayISO());
  const [time, setTime] = useState("09:00");
  const [duration, setDuration] = useState(60);
  const [recurrence, setRecurrence] = useState<Recurrence>("none");
  const [customWeeks, setCustomWeeks] = useState(3);

  useEffect(() => {
    setJobs(loadJobs());
  }, []);

  useEffect(() => {
    saveJobs(jobs);
  }, [jobs]);

  const sorted = useMemo(
    () =>
      [...jobs].sort(
        (a, b) =>
          new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime(),
      ),
    [jobs],
  );

  function resetForm() {
    setClient("");
    setAddress("");
    setSummary("");
    setDate(todayISO());
    setTime("09:00");
    setDuration(60);
    setRecurrence("none");
    setCustomWeeks(3);
  }

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!client.trim() || !address.trim() || !date) return;
    const job: Job = {
      id: crypto.randomUUID(),
      client: client.trim(),
      address: address.trim(),
      summary: summary.trim(),
      date,
      time,
      durationMin: duration,
      recurrence,
      customIntervalWeeks: recurrence === "custom" ? customWeeks : undefined,
      createdAt: Date.now(),
    };
    setJobs((j) => [...j, job]);
    downloadICS(job);
    resetForm();
    setShowForm(false);
  }

  function removeJob(id: string) {
    setJobs((j) => j.filter((x) => x.id !== id));
  }

  return (
    <div className="min-h-screen bg-background text-foreground pb-32">
      <header className="sticky top-0 z-10 backdrop-blur bg-background/80 border-b border-border">
        <div className="mx-auto max-w-xl px-5 pt-[env(safe-area-inset-top)]">
          <div className="py-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <img src="/icon-512.png" alt="" width={36} height={36} className="rounded-lg" />
              <div>
                <h1 className="text-lg font-semibold leading-tight">GreenSchedule</h1>
                <p className="text-xs text-muted-foreground">On-site notes &amp; bookings</p>
              </div>
            </div>
            <Link to="/board" className="text-xs font-medium text-primary hover:text-primary/80 px-3 py-1.5 rounded-md bg-accent/50 hover:bg-accent">
              Board
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-xl px-5 pt-6">
        {sorted.length === 0 && !showForm && (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">🌿</div>
            <h2 className="text-xl font-semibold mb-2">No jobs yet</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Add your first on-site visit and we'll book it straight into your calendar.
            </p>
          </div>
        )}

        <ul className="space-y-3">
          {sorted.map((job) => (
            <li key={job.id} className="rounded-2xl bg-card border border-border p-4 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="font-semibold truncate">{job.client}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {formatNice(job.date, job.time)} · {job.durationMin}m ·{" "}
                    <span className="text-primary font-medium">
                      {recurrenceLabel[job.recurrence]}
                      {job.recurrence === "custom" && ` (${job.customIntervalWeeks}w)`}
                    </span>
                  </p>
                </div>
                <button
                  onClick={() => removeJob(job.id)}
                  className="text-xs text-muted-foreground hover:text-destructive shrink-0"
                  aria-label="Delete job"
                >
                  ✕
                </button>
              </div>

              <a
                href={mapsUrl(job.address)}
                target="_blank"
                rel="noreferrer"
                className="mt-3 flex items-center gap-2 text-sm text-primary underline-offset-2 hover:underline break-words"
              >
                <span aria-hidden>📍</span>
                <span className="break-words">{job.address}</span>
              </a>

              {job.summary && (
                <p className="mt-3 text-sm whitespace-pre-wrap text-foreground/90 bg-secondary/50 rounded-lg p-3">
                  {job.summary}
                </p>
              )}

              <div className="mt-3 grid grid-cols-3 gap-2">
                <button
                  onClick={() => downloadICS(job)}
                  className="rounded-lg bg-primary text-primary-foreground text-sm font-medium py-2 active:opacity-80"
                >
                  Calendar
                </button>
                <a
                  href={directionsUrl(job.address)}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-lg bg-secondary text-secondary-foreground text-sm font-medium py-2 active:opacity-80 text-center"
                >
                  Directions
                </a>
                <button
                  onClick={() => shareJob(job)}
                  className="rounded-lg bg-secondary text-secondary-foreground text-sm font-medium py-2 active:opacity-80"
                >
                  Notes
                </button>
              </div>
            </li>
          ))}
        </ul>
      </main>

      {/* Floating add button */}
      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="fixed bottom-6 right-6 z-20 h-14 w-14 rounded-full bg-primary text-primary-foreground text-3xl leading-none shadow-lg active:scale-95 transition"
          style={{ marginBottom: "env(safe-area-inset-bottom)" }}
          aria-label="New job"
        >
          +
        </button>
      )}

      {/* Sheet */}
      {showForm && (
        <div
          className="fixed inset-0 z-30 bg-black/40 flex items-end"
          onClick={() => setShowForm(false)}
        >
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={handleSave}
            className="w-full max-w-xl mx-auto rounded-t-3xl bg-background p-5 pb-[calc(env(safe-area-inset-bottom)+1.5rem)] max-h-[92vh] overflow-y-auto"
          >
            <div className="mx-auto h-1.5 w-10 rounded-full bg-border mb-4" />
            <h2 className="text-lg font-semibold mb-4">New job</h2>

            <label className="block text-sm font-medium mb-1">Client</label>
            <input
              required
              value={client}
              onChange={(e) => setClient(e.target.value)}
              placeholder="e.g. Sarah Patel"
              className="w-full rounded-lg border border-input bg-card px-3 py-2.5 mb-3 text-base"
            />

            <label className="block text-sm font-medium mb-1">Address</label>
            <input
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="12 Oak Lane, Bristol"
              className="w-full rounded-lg border border-input bg-card px-3 py-2.5 mb-1 text-base"
            />
            {address && (
              <a
                href={mapsUrl(address)}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-primary mb-3 inline-block"
              >
                Open in Apple Maps →
              </a>
            )}

            <label className="block text-sm font-medium mb-1 mt-2">On-site summary</label>
            <textarea
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              rows={4}
              placeholder="Lawn mow, hedge trim along east fence, clear leaves from pond..."
              className="w-full rounded-lg border border-input bg-card px-3 py-2.5 mb-3 text-base"
            />

            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block text-sm font-medium mb-1">Date</label>
                <input
                  required
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full rounded-lg border border-input bg-card px-3 py-2.5 text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Time</label>
                <input
                  required
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full rounded-lg border border-input bg-card px-3 py-2.5 text-base"
                />
              </div>
            </div>

            <label className="block text-sm font-medium mb-1">Duration (minutes)</label>
            <input
              type="number"
              min={15}
              step={15}
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value) || 60)}
              className="w-full rounded-lg border border-input bg-card px-3 py-2.5 mb-3 text-base"
            />

            <label className="block text-sm font-medium mb-2">Recurrence</label>
            <div className="grid grid-cols-2 gap-2 mb-3">
              {(["none", "weekly", "fortnightly", "monthly", "custom"] as Recurrence[]).map((r) => (
                <button
                  type="button"
                  key={r}
                  onClick={() => setRecurrence(r)}
                  className={`rounded-lg border px-3 py-2 text-sm font-medium ${
                    recurrence === r
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-card text-foreground"
                  }`}
                >
                  {recurrenceLabel[r]}
                </button>
              ))}
            </div>

            {recurrence === "custom" && (
              <div className="mb-3">
                <label className="block text-sm font-medium mb-1">Repeat every (weeks)</label>
                <input
                  type="number"
                  min={1}
                  value={customWeeks}
                  onChange={(e) => setCustomWeeks(Math.max(1, Number(e.target.value) || 1))}
                  className="w-full rounded-lg border border-input bg-card px-3 py-2.5 text-base"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-2 mt-5">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="rounded-lg bg-secondary text-secondary-foreground font-medium py-3"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-primary text-primary-foreground font-medium py-3"
              >
                Save &amp; add to Calendar
              </button>
            </div>
            <p className="text-[11px] text-muted-foreground text-center mt-3">
              Saving downloads a .ics file — tap it to add the event (and recurrence) to Apple
              Calendar.
            </p>
          </form>
        </div>
      )}
    </div>
  );
}
