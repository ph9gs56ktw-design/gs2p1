// calendarExport: build a single-event .ics string for a job.
// Floating Europe/London local time so Apple Calendar shows the wall-clock time.

import { Job } from './types';

function pad(n: number) {
  return String(n).padStart(2, '0');
}

function formatLocalDateTime(date: Date) {
  return (
    date.getFullYear() +
    pad(date.getMonth() + 1) +
    pad(date.getDate()) +
    'T' +
    pad(date.getHours()) +
    pad(date.getMinutes()) +
    pad(date.getSeconds())
  );
}

function escapeText(value: string) {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/\n/g, '\\n')
    .replace(/,/g, '\\,')
    .replace(/;/g, '\\;');
}

function buildVTimezoneEuropeLondon() {
  return `BEGIN:VTIMEZONE
TZID:Europe/London
X-LIC-LOCATION:Europe/London
BEGIN:STANDARD
TZOFFSETFROM:+0100
TZOFFSETTO:+0000
TZNAME:GMT
DTSTART:19701025T020000
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU
END:STANDARD
BEGIN:DAYLIGHT
TZOFFSETFROM:+0000
TZOFFSETTO:+0100
TZNAME:BST
DTSTART:19700329T010000
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU
END:DAYLIGHT
END:VTIMEZONE`;
}

export function exportJobToICS(job: Job, start: Date, end: Date) {
  const uid = `${job.id}@greenschedule.local`;
  const dtstamp = formatLocalDateTime(new Date());
  const dtstart = formatLocalDateTime(start);
  const dtend = formatLocalDateTime(end);

  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//GreenSchedule//EN',
    'CALSCALE:GREGORIAN',
    buildVTimezoneEuropeLondon(),
    'BEGIN:VEVENT',
    `UID:${uid}`,
    `DTSTAMP:${dtstamp}`,
    `DTSTART;TZID=Europe/London:${dtstart}`,
    `DTEND;TZID=Europe/London:${dtend}`,
    `SUMMARY:${escapeText(job.title)}`,
    `LOCATION:${escapeText(job.location.address)}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}

// Convenience for the date-only model: default 09:00–10:00 window.
export function exportJobToICSDefaultWindow(job: Job) {
  const start = new Date(`${job.scheduledDate}T09:00:00`);
  const end = new Date(`${job.scheduledDate}T10:00:00`);
  return exportJobToICS(job, start, end);
}
