// RecurrenceEngine: given a job that was just completed, produce the next
// occurrence (or null if it does not recur). Date-only math, timezone-safe
// because we build and read Date using local components only.

import { Job } from './types';

function parseDate(yyyyMmDd: string): { y: number; m: number; d: number } {
  const [y, m, d] = yyyyMmDd.split('-').map(Number);
  return { y, m, d };
}

function formatDate(y: number, m: number, d: number): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${y}-${pad(m)}-${pad(d)}`;
}

function addDays(yyyyMmDd: string, days: number): string {
  const { y, m, d } = parseDate(yyyyMmDd);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  return formatDate(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
}

function addMonths(yyyyMmDd: string, months: number): string {
  const { y, m, d } = parseDate(yyyyMmDd);
  // Target year/month
  const targetMonthIndex = m - 1 + months;
  const targetYear = y + Math.floor(targetMonthIndex / 12);
  const normalisedMonth = ((targetMonthIndex % 12) + 12) % 12;
  // Clamp day to last valid day of the target month (e.g. 31 Jan -> 28/29 Feb)
  const lastDayOfTarget = new Date(targetYear, normalisedMonth + 1, 0).getDate();
  const day = Math.min(d, lastDayOfTarget);
  return formatDate(targetYear, normalisedMonth + 1, day);
}

function nextDate(scheduledDate: string, recurrence: Job['recurrence']): string | null {
  switch (recurrence) {
    case 'weekly':
      return addDays(scheduledDate, 7);
    case 'fortnightly':
      return addDays(scheduledDate, 14);
    case 'monthly':
      return addMonths(scheduledDate, 1);
    case 'none':
    default:
      return null;
  }
}

export const RecurrenceEngine = {
  // Returns a fresh scheduled job for the next occurrence, or null if non-recurring.
  expand(job: Job, makeId: () => string): Job | null {
    const next = nextDate(job.scheduledDate, job.recurrence);
    if (!next) return null;

    return {
      id: makeId(),
      title: job.title,
      status: 'scheduled',
      scheduledDate: next,
      location: { ...job.location },
      estimatedHours: job.estimatedHours,
      recurrence: job.recurrence,
      actualSeconds: 0,
      activeStartTime: undefined,
      lastExportedAt: undefined,
      overrideReason: undefined,
      history: [
        {
          timestamp: Date.now(),
          toStatus: 'scheduled',
          trigger: 'system_auto',
          reason: `recurrence:${job.recurrence}:from:${job.id}`,
        },
      ],
    };
  },
};
