// JobStore: single source of truth for jobs.
// - O(1) lookups via Map
// - structuredClone on every read/write so callers can never mutate internal state
// - SSR-safe: never touches localStorage or window on the server

import { Job, JobAuditLog } from './types';

type Listener = (jobs: Job[]) => void;

const STORAGE_KEY = 'greenschedule.kernel.jobs.v1';

const isBrowser = typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';

function clone<T>(value: T): T {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value)) as T;
}

export interface CreateJobInput {
  id: string;
  title: string;
  scheduledDate: string;
  location: Job['location'];
  estimatedHours: number;
  recurrence?: Job['recurrence'];
}

export class JobStore {
  private jobs = new Map<string, Job>();
  private listeners = new Set<Listener>();

  constructor(initial?: Job[]) {
    if (initial && initial.length) {
      initial.forEach(j => this.jobs.set(j.id, clone(j)));
      return;
    }
    // Hydrate from localStorage only in the browser.
    if (isBrowser) {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw) as Job[];
          parsed.forEach(j => this.jobs.set(j.id, clone(j)));
        }
      } catch {
        // Corrupt or unavailable storage: start empty rather than crash.
      }
    }
  }

  getAll(): Job[] {
    return Array.from(this.jobs.values()).map(j => clone(j));
  }

  get(id: string): Job | undefined {
    const job = this.jobs.get(id);
    return job ? clone(job) : undefined;
  }

  upsert(job: Job) {
    this.jobs.set(job.id, clone(job));
    this.emit();
  }

  remove(id: string) {
    this.jobs.delete(id);
    this.emit();
  }

  addJob(input: CreateJobInput): Job {
    const job: Job = {
      id: input.id,
      title: input.title,
      status: 'scheduled',
      scheduledDate: input.scheduledDate,
      location: input.location,
      estimatedHours: input.estimatedHours,
      recurrence: input.recurrence ?? 'none',
      actualSeconds: 0,
      activeStartTime: undefined,
      lastExportedAt: undefined,
      overrideReason: undefined,
      history: [
        {
          timestamp: Date.now(),
          toStatus: 'scheduled',
          trigger: 'system_auto',
          reason: 'job created',
        },
      ],
    };
    this.upsert(job);
    return clone(job);
  }

  appendHistory(jobId: string, entry: JobAuditLog): Job | undefined {
    const job = this.get(jobId);
    if (!job) return undefined;
    const updated: Job = { ...job, history: [...job.history, entry] };
    this.upsert(updated);
    return clone(updated);
  }

  subscribe(fn: Listener) {
    this.listeners.add(fn);
    fn(this.getAll());
    return () => {
      this.listeners.delete(fn);
    };
  }

  private emit() {
    const snapshot = this.getAll();
    this.listeners.forEach(l => l(snapshot));
    if (isBrowser) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
      } catch {
        // Storage full or blocked: keep running with in-memory state.
      }
    }
  }
}
