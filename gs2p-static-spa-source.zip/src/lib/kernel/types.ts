// Kernel type definitions.
// Date-only scheduling (no time-of-day). Recurrence supported.

export type JobStatus =
  | 'scheduled'
  | 'in_progress'
  | 'delayed'
  | 'rescheduled'
  | 'manual_override'
  | 'completed';

export type Trigger = 'user_action' | 'system_auto';

export type WeatherRisk = 'LOW' | 'MEDIUM' | 'HIGH';

export type Recurrence = 'none' | 'weekly' | 'fortnightly' | 'monthly';

export interface WeatherAssessment {
  precipitationProbability: number;
  riskLevel: WeatherRisk;
  suggestion: string;
  resolvedLocation?: { lat: number; lon: number };
}

export interface JobLocation {
  address: string;
  timeZone: 'Europe/London';
  lat?: number;
  lon?: number;
}

export interface JobAuditLog {
  timestamp: number;
  fromStatus?: JobStatus;
  toStatus: JobStatus;
  trigger: Trigger;
  reason?: string;
}

export interface Job {
  id: string;
  title: string;
  status: JobStatus;
  scheduledDate: string; // YYYY-MM-DD
  location: JobLocation;
  estimatedHours: number;
  recurrence: Recurrence;
  actualSeconds: number;
  activeStartTime?: number;
  lastExportedAt?: number;
  overrideReason?: string;
  history: JobAuditLog[];
}

export interface Day {
  date: string;
  jobIds: string[];
  totalHours: number;
  isOverloaded: boolean;
  weather?: {
    precipitationProbability: number;
    riskLevel: WeatherRisk;
  };
}

export interface SyncRecord {
  jobId: string;
  uid: string;
  lastHash: string;
  lastSyncedAt: number;
  deleted?: boolean;
}
