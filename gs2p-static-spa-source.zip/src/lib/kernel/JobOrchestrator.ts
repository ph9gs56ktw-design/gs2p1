// JobOrchestrator: the only place job state is allowed to change.
// Enforces legal transitions, records history, applies weather, and
// expands recurring jobs into their next occurrence on completion.

import { JobStore } from './JobStore';
import { DayStore } from './DayStore';
import { RecurrenceEngine } from './RecurrenceEngine';
import { JobStatus, Trigger, WeatherAssessment } from './types';

function makeId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  // Fallback for environments without crypto.randomUUID.
  return 'job-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

export class JobOrchestrator {
  constructor(
    private store: JobStore,
    private days: DayStore
  ) {}

  setStatus(
    jobId: string,
    status: JobStatus,
    meta?: { reason?: string; trigger?: Trigger }
  ) {
    const job = this.store.get(jobId);
    if (!job) return;

    const trigger: Trigger = meta?.trigger ?? 'user_action';

    if (job.status === status) return;
    if (job.status === 'completed') return; // completed is locked
    if (job.status === 'manual_override' && trigger === 'system_auto') return;
    if (!this.canTransition(job.status, status, trigger)) return;

    this.store.upsert({
      ...job,
      status,
      history: [
        ...job.history,
        {
          timestamp: Date.now(),
          fromStatus: job.status,
          toStatus: status,
          trigger,
          reason: meta?.reason,
        },
      ],
      overrideReason:
        status === 'manual_override' ? meta?.reason ?? job.overrideReason : undefined,
    });

    // On completion, spawn the next occurrence of a recurring job.
    if (status === 'completed') {
      const completed = this.store.get(jobId);
      if (completed) {
        const next = RecurrenceEngine.expand(completed, makeId);
        if (next) this.store.upsert(next);
      }
    }
  }

  move(jobId: string, date: string) {
    const job = this.store.get(jobId);
    if (!job) return;
    if (job.scheduledDate === date) return;
    this.store.upsert({ ...job, scheduledDate: date });
  }

  applyWeather(date: string, assessment: WeatherAssessment) {
    const jobs = this.store.getAll();
    const day = this.days.getDay(date, jobs);
    if (!day) return;
    if (assessment.riskLevel !== 'HIGH') return;

    for (const id of day.jobIds) {
      const job = this.store.get(id);
      if (!job) continue;
      if (job.status === 'completed' || job.status === 'manual_override') continue;
      if (job.status === 'delayed') continue;

      this.setStatus(id, 'delayed', {
        reason: `weather:${date}:${assessment.riskLevel}`,
        trigger: 'system_auto',
      });
    }
  }

  private canTransition(from: JobStatus, to: JobStatus, trigger: Trigger): boolean {
    const userRules: Partial<Record<JobStatus, JobStatus[]>> = {
      scheduled: ['in_progress', 'delayed', 'rescheduled', 'manual_override'],
      in_progress: ['completed', 'delayed', 'manual_override'],
      delayed: ['scheduled', 'rescheduled', 'manual_override'],
      rescheduled: ['scheduled', 'manual_override'],
      manual_override: ['scheduled', 'in_progress', 'delayed', 'rescheduled', 'completed'],
      completed: [],
    };

    const autoRules: Partial<Record<JobStatus, JobStatus[]>> = {
      scheduled: ['delayed', 'rescheduled'],
      in_progress: ['delayed'],
      delayed: [],
      rescheduled: [],
      manual_override: [],
      completed: [],
    };

    const rules = trigger === 'system_auto' ? autoRules : userRules;
    return (rules[from] ?? []).includes(to);
  }
}
