// DayStore: pure projection of jobs into per-day aggregates.
// No state of its own. Call compute(jobs) any time the job list changes.

import { Day, Job } from './types';

const MAX_HOURS_PER_DAY = 8;

export class DayStore {
  compute(jobs: Job[]): Map<string, Day> {
    const map = new Map<string, Day>();
    for (const job of jobs) {
      // Completed and rescheduled jobs do not count toward a day's load.
      if (job.status === 'completed' || job.status === 'rescheduled') continue;

      const day =
        map.get(job.scheduledDate) ?? {
          date: job.scheduledDate,
          jobIds: [],
          totalHours: 0,
          isOverloaded: false,
        };

      if (!day.jobIds.includes(job.id)) day.jobIds.push(job.id);
      day.totalHours += job.estimatedHours;
      day.isOverloaded = day.totalHours > MAX_HOURS_PER_DAY;
      map.set(job.scheduledDate, day);
    }
    return map;
  }

  getDay(date: string, jobs: Job[]): Day | undefined {
    return this.compute(jobs).get(date);
  }
}
