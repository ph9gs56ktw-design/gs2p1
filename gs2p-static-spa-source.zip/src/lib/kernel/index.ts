// Public kernel surface + shared singletons.
// Singletons are created lazily so importing this file on the server is safe.

import { JobStore } from './JobStore';
import { DayStore } from './DayStore';
import { JobOrchestrator } from './JobOrchestrator';

export * from './types';
export { JobStore } from './JobStore';
export { DayStore } from './DayStore';
export { JobOrchestrator } from './JobOrchestrator';
export { RecurrenceEngine } from './RecurrenceEngine';
export { exportJobToICS, exportJobToICSDefaultWindow } from './calendarExport';

let _store: JobStore | null = null;
let _days: DayStore | null = null;
let _orchestrator: JobOrchestrator | null = null;

export function getJobStore(): JobStore {
  if (!_store) _store = new JobStore();
  return _store;
}

export function getDayStore(): DayStore {
  if (!_days) _days = new DayStore();
  return _days;
}

export function getOrchestrator(): JobOrchestrator {
  if (!_orchestrator) {
    _orchestrator = new JobOrchestrator(getJobStore(), getDayStore());
  }
  return _orchestrator;
}
