// useKernel: connects React to the kernel singletons.
// Safe under SSR — subscription happens in useEffect (client only).

import { useEffect, useMemo, useState } from 'react';
import {
  getJobStore,
  getDayStore,
  getOrchestrator,
  type Job,
  type Day,
} from '@/lib/kernel';

export function useKernel() {
  const store = getJobStore();
  const dayStore = getDayStore();
  const orchestrator = getOrchestrator();

  const [jobs, setJobs] = useState<Job[]>(() => store.getAll());

  useEffect(() => {
    const unsub = store.subscribe(setJobs);
    return () => unsub();
  }, [store]);

  const days: Day[] = useMemo(
    () => Array.from(dayStore.compute(jobs).values()).sort((a, b) => a.date.localeCompare(b.date)),
    [jobs, dayStore]
  );

  return { store, dayStore, orchestrator, jobs, days };
}
