# Deploy GreenSchedule Static to Netlify

## Option A: Deploy via GitHub (Recommended for iOS)

**Best if you can push code to GitHub. Netlify builds automatically.**

### Steps:

1. **Push this source code to your GitHub repo:**
   ```bash
   git add .
   git commit -m "Migrate from TanStack Start SSR to static React SPA"
   git push origin main
   ```

2. **On Netlify:**
   - Go to your site (jovial-fairy-402e35)
   - Go to **Settings** → **Build & Deploy** → **Build Settings**
   - Verify build command: `pnpm run build`
   - Verify publish directory: `dist`
   - Click **Save**

3. **Trigger new deploy:**
   - Go to **Deploys** tab
   - Click **Trigger deploy** (or push another commit)
   - Wait 2–3 minutes for Netlify to build and deploy

**That's it.** Netlify will run `pnpm build`, output to `dist/`, and serve it with `_redirects`.

---

## Option B: Deploy Static Files (Drag & Drop)

**If you have a Mac/PC with the built files.**

### Steps:

1. **Build locally** (on your computer):
   ```bash
   pnpm install
   pnpm build
   ```
   This creates a `dist/` folder with all static files.

2. **Add _redirects to dist/:**
   - Copy the `_redirects` file from root into `dist/`

3. **Drag `dist/` to Netlify:**
   - Go to your site on Netlify
   - Drag the `dist/` folder to the deploy zone
   - Wait 30 seconds

---

## Option C: Manual Upload (No Build)

**If you want to skip the build step (risky).**

1. Extract this zip
2. Remove: `src/`, `vite.config.ts`, `package.json`, `tsconfig.json`
3. Keep only: `_redirects`, `manifest.webmanifest`, `icon-512.png`, `robots.txt`, and any `index.html`
4. Drag to Netlify

⚠️ **This won't work** because the source code hasn't been compiled to JavaScript. Skip this option.

---

## Check Deployment

Once deployed:

1. **Visit your site:** https://jovial-fairy-402e35.netlify.app/
2. **Test navigation:**
   - Click "Board" (goes to `/board`)
   - Refresh the page → should still show Board (no 404)
3. **Test features:**
   - Add a job
   - Export to calendar
   - Check localStorage persists after refresh

---

## Troubleshooting

**Still blank page?**
- Make sure `_redirects` is in the root of deployed files
- Check Netlify **Deploys** → most recent deploy → **Deploy log**
- Look for build errors or 404s

**Got an error?**
- Check browser console (F12 → Console tab) for JavaScript errors
- Share the error message

---

## What's Different?

✓ No more SSR (server-side rendering)  
✓ Pure static + client-side routing  
✓ Smaller, faster  
✓ All functionality preserved  

See `CONVERSION.md` for full details.
